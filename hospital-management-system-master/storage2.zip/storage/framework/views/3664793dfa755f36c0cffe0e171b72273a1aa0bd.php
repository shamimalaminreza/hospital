<?php $__env->startSection('top_header'); ?>
<!-- content panel -->
<div class="main-panel">
  <!-- top header -->
  <header class="header navbar">

    <div class="brand visible-xs">
      <!-- toggle offscreen menu -->
      <div class="toggle-offscreen">
        <a href="#" class="hamburger-icon v2 visible-xs" data-toggle="offscreen" data-move="ltr">
          <span></span>
          <span></span>
          <span></span>
        </a>
      </div>
      <!-- /toggle offscreen menu -->

      <!-- logo -->
      <div class="brand-logo">
        Trust One Hospital
      </div>
      <!-- /logo -->
    </div>

    <ul class="nav navbar-nav hidden-xs">
      <li>
        <p class="navbar-text">
          View All Admit Patient's
        </p>
      </li>
    </ul>

    <ul class="nav navbar-nav navbar-right hidden-xs">

      <li>
        <a href="javascript:;" data-toggle="dropdown">
          <img src="<?php echo e(asset('images/avatar.jpg')); ?>" class="header-avatar img-circle ml10" alt="user" title="user">
          <span class="pull-left">Trust One Hospital</span>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li>
            <a href="signin.html">Logout</a>
          </li>
        </ul>

      </li>

    </ul>
  </header>
  <!-- /top header -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">
  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          Patients Information
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-striped mb0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>ID</th>
              <th>Phone</th>
              <th>View</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>ID</th>
              <th>Phone</th>
              <th>View</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php foreach($patients as $patient): ?>
              <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($patient->name); ?></td>
              <td><?php echo e($patient->id); ?></td>
              <td><?php echo e($patient->mobile); ?></td>
              <td><a data-toggle="modal" data-target="#details<?php echo $i; ?>" href=""><button type="button" class="btn btn-success">Details</button></a></td>
              <div class="modal" id="details<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Patient's Information</h4>
                    </div>
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-4">
                          <p>Name</p>
                          <p>Patient Type</p>
                          <p>Patient ID</p>
                          <p>Gender</p>
                          <p>Birth Date</p>
                          <p>Blood Group</p>
                          <p>Symptoms</p>
                          <p>Selected Doctor</p>
                          <p>Admition Time</p>
                          <p>Allocated Seat</p>
                          <p>Mobile Number</p>
                          <p>Email</p>
                          <p>Address</p>
                          <p>Image Preview</p>
                        </div>
                        <div class="col-xs-7">
                          <p> : <?php echo e($patient->name); ?></p>
                          <p> : Admit</p>
                          <p> : <?php echo e(isset($patient->id) ? $patient->id : '101'); ?></p>
                          <p> : <?php echo e($patient->gender); ?></p>
                          <p> : <?php echo e($patient->birthDate); ?></p>
                          <p> : <?php echo e($patient->bloodGroup); ?></p>
                          <p> : <?php echo e($patient->symptoms); ?></p>
                          <p> : <?php echo e($patient->employee->name); ?></p>
                          <p> : <?php echo e($patient->created_at); ?></p>
                          <p> : <?php echo e($patient->seat->seatFloor); ?> -- <?php echo e($patient->seat->seatNo); ?></p>
                          <p> : <?php echo e($patient->mobile); ?> </p>
                          <p> : <?php echo e($patient->email); ?></p>
                          <p> : <?php echo e($patient->address); ?></p>
                          <p> : <img class="img-responsive" src="<?php echo e(asset('images/patients/'.$patient->image)); ?>" ></p>
                </div>
                      </div>
                    </div>
                    <div class="modal-footer no-border">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              
              <td><a data-toggle="modal" data-target="#edit<?php echo $i; ?>" href=""><button type="button" class="btn btn-info">Edit</button></a></td>
              <div class="modal" id="edit<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Edit Information</h4>
                    </div>
                    <div class="modal-body">
                      <form class="form-horizontal bordered-group" role="form" action="<?php echo e(route('patient.update')); ?>" method="post" enctype="multipart/form-data">

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Patient ID</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" value="<?php echo e($patient->id); ?>" disabled>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(Request::old('name') ? Request::old('name') : isset($patient) ? $patient->name : ''); ?>" required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Gender</label>
              <div class="col-sm-8"> 
                <label class="radio-inline">
                  <input type="radio" name="gender" id="inlineRadio1" value="Male" <?php echo e($patient->gender == 'Male' ? 'checked' : ''); ?>> Male
                </label>
                <label class="radio-inline">
                  <input type="radio" name="gender" id="inlineRadio2" value="Female" <?php echo e($patient->gender == 'Female' ? 'checked' : ''); ?>> Female
                </label>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Date of Birth</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" data-provide="datepicker" name="birthDate" value="<?php echo e(Request::old('birthDate') ? Request::old('birthDate') : isset($patient) ? $patient->birthDate : ''); ?>" required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Blood Group</label>
              <div class="col-sm-8">
                <select class="form-control" name="bloodGroup">
                  <option value="A+" <?php echo e($patient->bloodGroup == 'A+' ? 'selected' : ''); ?>>A+</option>
                  <option value="O+" <?php echo e($patient->bloodGroup == 'O+' ? 'selected' : ''); ?>>O+</option>
                  <option value="B+" <?php echo e($patient->bloodGroup == 'B+' ? 'selected' : ''); ?>>B+</option>
                  <option value="AB+" <?php echo e($patient->bloodGroup == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                  <option value="A-" <?php echo e($patient->bloodGroup == 'A-' ? 'selected' : ''); ?>>A-</option>
                  <option value="B-" <?php echo e($patient->bloodGroup == 'B-' ? 'selected' : ''); ?>>B-</option>
                  <option value="O-" <?php echo e($patient->bloodGroup == 'O-' ? 'selected' : ''); ?>>O-</option>
                  <option value="AB-" <?php echo e($patient->bloodGroup == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                </select>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Symptoms</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="symptoms" placeholder="Symptoms" value="<?php echo e(Request::old('symptoms') ? Request::old('symptoms') : isset($patient) ? $patient->symptoms : ''); ?>" required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Assign Doctor</label>
              <div class="col-sm-8">
                <select class="form-control" name="doctor_id">
                  <?php foreach($employees as $employee): ?>
                    <option value="<?php echo e($employee->id); ?>" <?php echo e($employee->id == $patient->employee->id ? 'selected' : ''); ?>><?php echo e($employee->name); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Assign Seat</label>
              <div class="col-sm-8">
                <select class="form-control" name="seat_id">
                  <?php foreach($seats as $seat): ?>
                    <option value="<?php echo e($seat->id); ?>" <?php echo e($seat->id == $patient->seat->id ? "selected" : ''); ?>><?php echo e($seat->seatFloor); ?> -- <?php echo e($seat->seatNo); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Mobile Number</label> 
              <div class="col-sm-8">
                <input class="form-control" type="tel" pattern="^\d{11}$" required name="mobile" name="mobile" value="<?php echo e(Request::old('mobile') ? Request::old('mobile') : isset($patient) ? $patient->mobile : ''); ?>">
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Email</label>
              <div class="col-sm-8">
                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(Request::old('email') ? Request::old('email') : isset($patient) ? $patient->email : ''); ?>">
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Address</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="address" placeholder="Address" value="<?php echo e(Request::old('address') ? Request::old('address') : isset($patient) ? $patient->address : ''); ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="col-sm-3 control-label">Previous Image</label>
              <div class="col-sm-8">
                <img src="<?php echo e(asset('images/patients/'.$patient->image)); ?>" class="img-responsive" alt="">
                <input class="mt25" type="file" name="image">
              </div>
            </div>

                    </div>
                    <div class="modal-footer no-border">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-success">Update</button>
                      <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                      <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                    </div>
                  </div>
                </div>
              </div>
               </form>
              

              <td><a data-toggle="modal" data-target="#delete<?php echo $i; ?>" href=""><button type="button" class="btn btn-danger">Delete</button></a></td>
              <div class="modal" id="delete<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Delete Patients Information</h4>
                  </div>
                  <div class="modal-body">
                      Are you sure ?
                  </div>
                  <form action="<?php echo e(route('patient.delete')); ?>" method="">
                  <div class="modal-footer no-border">
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                  </div>
                  </form>
                </div>
              </div>
              </div>
            </tr>
            <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
        <section>
        <nav>
          <ul class="pager">
              <?php if($patients->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($patients->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($patients->currentPage() !== $patients->lastPage() && $patients->hasPages()): ?>
                <li class="next"><a href="<?php echo e($patients->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>