<?php $__env->startSection('top_header'); ?>
  View All Paid Report
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">
  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          View All PAID Report List
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-striped mb0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Report ID</th>
              <th>P. ID</th>
              <th>View</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No.</th>
              <th>Report ID</th>
              <th>P. ID</th>
              <th>View</th>
              <th>Delete</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php foreach($invoiceouts as $invoiceout): ?>
              <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($invoiceout->id); ?></td>
              <td><?php echo e($invoiceout->patientout_id); ?></td>
              <td>
                <form action="<?php echo e(route('invoiceout.view')); ?>" method="GET">
                  <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="GET">
                <input type="hidden" name="invoiceout_id" value="<?php echo e($invoiceout->id); ?>">
                <button class="btn btn-primary">Print</button>
                </form>
              </td>
              
              
              <td><a data-toggle="modal" data-target="#delete<?php echo $i; ?>" href=""><button type="button" class="btn btn-danger">Delete</button></a></td>
              <div class="modal" id="delete<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Delete Report's Information</h4>
                  </div>
                  <div class="modal-body">
                      Are you sure ?
                  </div>
                  <form action="<?php echo e(route('invoiceout.destroy' , $invoiceout->id)); ?>" method="POST">
                  <input name="_method" type="hidden" value="DELETE">
                  <?php echo e(csrf_field()); ?>


                  <div class="modal-footer no-border">
                      <button type="button" class="btn btn-info" data-dismiss="modal">No</button>
                      <button type="submit" class="btn btn-primary">Yes</button>
                  </div>
                  </form>
                </div>
              </div>
              </div>
            </tr>
            <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
        <section>
        <nav>
          <ul class="pager">
              <?php if($invoiceouts->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($invoiceouts->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($invoiceouts->currentPage() !== $invoiceouts->lastPage() && $invoiceouts->hasPages()): ?>
                <li class="next"><a href="<?php echo e($invoiceouts->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('run_custom_jquery'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>