<?php $__env->startSection('top_header'); ?>
<!-- content panel -->
<div class="main-panel">
  <!-- top header -->
  <header class="header navbar">

    <div class="brand visible-xs">
      <!-- toggle offscreen menu -->
      <div class="toggle-offscreen">
        <a href="#" class="hamburger-icon v2 visible-xs" data-toggle="offscreen" data-move="ltr">
          <span></span>
          <span></span>
          <span></span>
        </a>
      </div>
      <!-- /toggle offscreen menu -->

      <!-- logo -->
      <div class="brand-logo">
        Trust One Hospital
      </div>
      <!-- /logo -->
    </div>

    <ul class="nav navbar-nav hidden-xs">
      <li>
        <p class="navbar-text">
          Employee Category
        </p>
      </li>
    </ul>

    <ul class="nav navbar-nav navbar-right hidden-xs">

      <li>
        <a href="javascript:;" data-toggle="dropdown">
          <img src="<?php echo e(asset('images/avatar.jpg')); ?>" class="header-avatar img-circle ml10" alt="user" title="user">
          <span class="pull-left">Trust One Hospital</span>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li>
            <a href="signin.html">Logout</a>
          </li>
        </ul>

      </li>

    </ul>
  </header>
  <!-- /top header -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">

  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          Add New Category
        </div>
        <form action="<?php echo e(route('ecategory.store')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="panel-body">
        <?php if(Session::has('success1')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success1')); ?>

        </div>
       <?php endif; ?>
          <div class="form-group">
              <label class="col-sm-2 control-label">Category Name</label>
              <div class="col-sm-7">
                <input type="text" class="form-control" name="name" required>
              </div>
            </div>
        </div>
        <div class="panel-footer" style="overflow: hidden;">
          <button type="submit" class="btn btn-success pull-right">Save</button>
        </div>
        </form>
    </div>
  </div>

  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
         View ALL Category Information
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-striped mb0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php foreach($ecategorys as $ecategory): ?>
              <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($ecategory->name); ?></td>
              
              <td><a data-toggle="modal" data-target="#edit<?php echo $i; ?>" href=""><button type="button" class="btn btn-info">Edit</button></a></td>
              <div class="modal" id="edit<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Edit Information</h4>
                    </div>
                    <div class="modal-body">
                      <div class="row mb25">
              <form class="form-horizontal bordered-group" role="form" action="<?php echo e(route('ecategory.update' , $ecategory->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="PUT">

          
            <div class="form-group clear">
              <label class="col-sm-3 control-label">Category Name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="name" value="<?php echo e(Request::old('name') ? Request::old('name') : isset($ecategory) ? $ecategory->name : ''); ?> " required>
              </div>
            </div>

              </div>
              </div>
              <div class="modal-footer no-border">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Update</button>
              </div>
            </div>
          </div>
        </div>
         </form>
              

              <td><a data-toggle="modal" data-target="#delete<?php echo $i; ?>" href=""><button type="button" class="btn btn-danger">Delete</button></a></td>
              <div class="modal" id="delete<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Delete ecategorys Information</h4>
                  </div>
                  <div class="modal-body">
                      Are you sure ?
                  </div>
                    <form action="<?php echo e(route('ecategory.destroy' , $ecategory->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                  <input name="_method" type="hidden" value="DELETE">
                  <div class="modal-footer no-border">
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary">Yes</button>
                  </div>
                  </form>
                </div>
              </div>
              </div>
            </tr>
            <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
        <section>
        <nav>
          <ul class="pager">
              <?php if($ecategorys->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($ecategorys->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($ecategorys->currentPage() !== $ecategorys->lastPage() && $ecategorys->hasPages()): ?>
                <li class="next"><a href="<?php echo e($ecategorys->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>