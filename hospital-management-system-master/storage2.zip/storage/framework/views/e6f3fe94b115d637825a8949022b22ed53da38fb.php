<?php $__env->startSection('top_header'); ?>
<!-- content panel -->
<div class="main-panel">
  <!-- top header -->
  <header class="header navbar">

    <div class="brand visible-xs">
      <!-- toggle offscreen menu -->
      <div class="toggle-offscreen">
        <a href="#" class="hamburger-icon v2 visible-xs" data-toggle="offscreen" data-move="ltr">
          <span></span>
          <span></span>
          <span></span>
        </a>
      </div>
      <!-- /toggle offscreen menu -->

      <!-- logo -->
      <div class="brand-logo">
        Trust One Hospital
      </div>
      <!-- /logo -->
    </div>

    <ul class="nav navbar-nav hidden-xs">
      <li>
        <p class="navbar-text">
          View All Report's
        </p>
      </li>
    </ul>

    <ul class="nav navbar-nav navbar-right hidden-xs">

      <li>
        <a href="javascript:;" data-toggle="dropdown">
          <img src="<?php echo e(asset('images/avatar.jpg')); ?>" class="header-avatar img-circle ml10" alt="user" title="user">
          <span class="pull-left">Trust One Hospital</span>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li>
            <a href="signin.html">Logout</a>
          </li>
        </ul>

      </li>

    </ul>
  </header>
  <!-- /top header -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">
  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          Report List on <?php echo e($village->name); ?> at 
          <?php echo e($day); ?>

          <?php if($month==01): ?>January
          <?php elseif($month==02): ?>February
          <?php elseif($month==03): ?>March
          <?php elseif($month==04): ?>April
          <?php elseif($month==05): ?>May
          <?php elseif($month==06): ?>June
          <?php elseif($month==07): ?>July
          <?php elseif($month==08): ?>August
          <?php elseif($month==09): ?>September
          <?php elseif($month==10): ?>October
          <?php elseif($month==11): ?>November
          <?php elseif($month==12): ?>December
          <?php endif; ?>
          <?php echo e($year); ?>

          
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>S. No</th>
              <th>Report ID</th>
              <th>Total</th>
              <th>Hospital</th>
              <th>Less</th>
              <th>Pay</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>S. No</th>
              <th>Report ID</th>
              <th>Total</th>
              <th>Hospital</th>
              <th>Less</th>
              <th>Pay</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php  
              $subtotal = 0
             ?>
            <?php 
              $hospital = 0
             ?>
            <?php 
              $less = 0
             ?>
            <?php 
              $pay = 0
             ?>
            <?php foreach($invoiceouts as $invoiceout): ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($invoiceout->id); ?></td>
              <td><?php echo e($invoiceout->subtotal); ?></td>
              <td><?php echo e($invoiceout->subtotal / 2); ?></td>
              <td><?php echo e($invoiceout->percent_amount + $invoiceout->discount); ?></td>
              <td><?php echo e(($invoiceout->subtotal / 2) - ($invoiceout->percent_amount + $invoiceout->discount)); ?></td>
            </tr>
            <?php $i++; ?>
            <?php  
              $subtotal += $invoiceout->subtotal 
             ?>
            <?php  
              $hospital += $invoiceout->subtotal / 2 
             ?>
            <?php  
              $less += $invoiceout->percent_amount + $invoiceout->discount
             ?>
            <?php  
              $pay += ($invoiceout->subtotal / 2) - ($invoiceout->percent_amount + $invoiceout->discount)
             ?>

            <?php endforeach; ?>
          </tbody>
        </table>
        <hr/>
      <div class="row">
          <div class="col-md-6"></div>
          <div class="col-md-6">
           <table class="table table-bordered table-hover">
           <tbody>
              <thead>
                <th>Description</th>
                <th>Amount</th>
              </thead>
              <tr>
                <td>Total</td>
                <td><?php echo e($subtotal); ?> Tk.</td>
              </tr>
              <tr>
                <td>Hospital</td>
                <td><?php echo e($hospital); ?> Tk.</td>
              </tr>
              <tr>
                <td>Less</td>
                <td><?php echo e($less); ?> Tk.</td>
              </tr>
              <tr>
                <td><?php echo e($village->name); ?></td>
                <td><?php echo e($pay); ?> Tk.</td>
              </tr>

          </tbody>
          </table>
        </div>
      </div>
        <section>
        <nav>
          <ul class="pager">
              <?php if($invoiceouts->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($invoiceouts->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($invoiceouts->currentPage() !== $invoiceouts->lastPage() && $invoiceouts->hasPages()): ?>
                <li class="next"><a href="<?php echo e($invoiceouts->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>