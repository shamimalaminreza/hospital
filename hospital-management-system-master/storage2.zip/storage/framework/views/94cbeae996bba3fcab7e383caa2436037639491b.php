<?php $__env->startSection('top_header'); ?>
  View All Patients
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">
  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          Visiting List on <?php echo e($doctor->name); ?> at 
          <?php echo e($day); ?>

          <?php if($month==01): ?>January
          <?php elseif($month==02): ?>February
          <?php elseif($month==03): ?>March
          <?php elseif($month==04): ?>April
          <?php elseif($month==05): ?>May
          <?php elseif($month==06): ?>June
          <?php elseif($month==07): ?>July
          <?php elseif($month==08): ?>August
          <?php elseif($month==09): ?>September
          <?php elseif($month==10): ?>October
          <?php elseif($month==11): ?>November
          <?php elseif($month==12): ?>December
          <?php endif; ?>
          <?php echo e($year); ?>

          
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-striped mb0">
          <thead>
            <tr>
              <th>S. No</th>
              <th>P. Name</th>
              <th>P. ID</th>
              <th>View</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>S. No</th>
              <th>P. Name</th>
              <th>P. ID</th>
              <th>View</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php foreach($patients as $patient): ?>
              <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($patient->name); ?></td>
              <td><?php echo e($patient->id); ?></td>
              <td>
                <form action="<?php echo e(route('doctor.view')); ?>" method="GET">
                  <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="GET">
                <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                <input type="hidden" name="doctor_id" value="<?php echo e($doctor->id); ?>">
                <input type="hidden" name="serial" value="<?php echo $i; ?>">
                <button class="btn btn-primary">Print</button>
                </form>
              </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
        <section>
        <nav>
          <ul class="pager">
              <?php if($patients->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($patients->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($patients->currentPage() !== $patients->lastPage() && $patients->hasPages()): ?>
                <li class="next"><a href="<?php echo e($patients->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>