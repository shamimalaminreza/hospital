<?php $__env->startSection('top_header'); ?>
  Outdoor Patients Information
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- main area -->
<div class="main-content">

  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
          Add New Patient
        </div>
        <form action="<?php echo e(route('patientout.store')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="panel-body">
        <?php if(Session::has('success1')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success1')); ?>

        </div>
       <?php endif; ?>
          <div class="form-group clear">
            <label class="col-sm-2 control-label">Patient Name</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="name" required>
            </div>
          </div>

          <div class="form-group clear">
            <label class="col-sm-2 control-label">Mobile No.</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="mobile" required>
            </div>
          </div>

          <div class="form-group clear">
            <label class="col-sm-2 control-label">Address</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="address" required>
            </div>
          </div>

          <div class="form-group clear">
            <label class="col-sm-2 control-label">Visiting Doctor</label>
            <div class="col-sm-7">
              <select class="form-control" name="doctor_id" id="doctor_id">
                <option value="">Select Doctor</option>
                <?php foreach($doctors as $doctor): ?>
                  <option value="<?php echo e($doctor->id); ?>"><?php echo e($doctor->name); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-group clear">
            <label class="col-sm-2 control-label">Visiting Charge</label>
            <div class="col-sm-7" id="visiting_charge">
              <input type="text" class="form-control" disabled>
            </div>
          </div>

          <div class="form-group clear">
            <label class="col-sm-2 control-label">Receive Cash</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="receive_cash" required>
            </div>
          </div>


        </div>
        <div class="panel-footer" style="overflow: hidden;">
          <button type="submit" class="btn btn-success pull-right">Save</button>
        </div>
        </form>
    </div>
  </div>

  <div class="row">
    <div class="panel mb25">
        <div class="panel-heading border">
         View ALL Outdoor Patient
        </div>
        <div class="panel-body">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>
        
        <div class="table-responsive">
        <table class="table table-bordered table-striped mb0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>ID</th>
              <th>View</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>ID</th>
              <th>View</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $i =1 ; ?>
            <?php foreach($patientouts as $patientout): ?>
              <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo e($patientout->name); ?></td>
              <td><?php echo e($patientout->id); ?></td>
              <td><a data-toggle="modal" data-target="#details<?php echo $i; ?>" href=""><button type="button" class="btn btn-success">Details</button></a></td>
              <div class="modal" id="details<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Patient's Information</h4>
                    </div>
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-4">
                          <p>ID</p>
                          <p>Name</p>
                          <p>Mobile</p>
                          <p>Address</p>
                          <p>Visiting Doctor</p>
                        </div>
                        <div class="col-xs-7">
                          <p> : <?php echo e($patientout->id); ?></p>
                          <p> : <?php echo e($patientout->name); ?></p>
                          <p> : <?php echo e($patientout->mobile); ?></p>
                          <p> : <?php echo e($patientout->address); ?></p>
                          <p> : <?php echo e($patientout->doctor->name); ?></p>
                        </div>
                      </div>
                    </div>
                    <div class="modal-footer no-border">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              

              <td><a data-toggle="modal" data-target="#edit<?php echo $i; ?>" href=""><button type="button" class="btn btn-info">Edit</button></a></td>
              <div class="modal" id="edit<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Edit Information</h4>
                    </div>
                    <div class="modal-body">
                      <div class="row mb25">
              <form class="form-horizontal bordered-group" role="form" action="<?php echo e(route('patientout.update' , $patientout->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="PUT">

          
            <div class="form-group clear">
              <label class="col-sm-3 control-label">Name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="name" value="<?php echo e(Request::old('name') ? Request::old('name') : isset($patientout) ? $patientout->name : ''); ?> " required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Mobile</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="mobile" value="<?php echo e(Request::old('mobile') ? Request::old('mobile') : isset($patientout) ? $patientout->mobile : ''); ?> " required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Address</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="address" value="<?php echo e(Request::old('address') ? Request::old('address') : isset($patientout) ? $patientout->address : ''); ?> " required>
              </div>
            </div>

            <div class="form-group clear">
              <label class="col-sm-3 control-label">Visiting Doctor</label>
              <div class="col-sm-8">
                <select class="form-control" name="doctor_id">
                <?php foreach($doctors as $doctor): ?>
                  <option value="<?php echo e($doctor->id); ?>" <?php echo e($patientout->doctor_id == $doctor->id ? 'selected'  : ''); ?> > <?php echo e($doctor->name); ?> </option>
                <?php endforeach; ?>
                </select>
              </div>
            </div>

              </div>
              </div>
              <div class="modal-footer no-border">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Update</button>
              </div>
            </div>
          </div>
        </div>
         </form>
              

              <td><a data-toggle="modal" data-target="#delete<?php echo $i; ?>" href=""><button type="button" class="btn btn-danger">Delete</button></a></td>
              <div class="modal" id="delete<?php echo $i; ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Delete Outdoor Patient</h4>
                  </div>
                  <div class="modal-body">
                      Are you sure ?
                  </div>
                    <form action="<?php echo e(route('patientout.destroy' , $patientout->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                  <input name="_method" type="hidden" value="DELETE">
                  <div class="modal-footer no-border">
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary">Yes</button>
                  </div>
                  </form>
                </div>
              </div>
              </div>
            </tr>
            <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
        </table>
        <section>
        <nav>
          <ul class="pager">
              <?php if($patientouts->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($patientouts->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($patientouts->currentPage() !== $patientouts->lastPage() && $patientouts->hasPages()): ?>
                <li class="next"><a href="<?php echo e($patientouts->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
      </section>
      </div>

      </div>
    </div>
  </div>
  <!-- /main area -->
</div>
<!-- /content panel -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('run_custom_jquery'); ?>
<script type="text/javascript">
  $('#doctor_id').on('change' , function(e){
    var doctor_id = e.target.value;

    $.get('/hospital/public/patientout_api?doctor_id=' + doctor_id, function(data){
      $('#visiting_charge').empty();
      $.each(data, function(index,chargeobj){
        $('#visiting_charge').append('<input type="text" name="visiting_charge" class="form-control" value="'+chargeobj.charge+'"disabled>')
      });
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>