(function ($) {
  'use strict';

  $('.datatable').dataTable({
    'ajax': 'data/datatables-arrays.json'
  });

})(jQuery);
