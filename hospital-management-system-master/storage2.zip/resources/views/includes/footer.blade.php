  <!-- bottom footer -->
    <footer class="content-footer">

      <nav>
        <ul class="nav" style="text-align: center;">
          <li>
            <a href="http://www.somrat.info">Developed By : SOMRAT IT</a>
          </li>
        </ul>
      </nav>

      <!-- <nav class="footer-right">
        <ul class="nav">
          <li>
            <a href="www.somrat.info">
                Developed by SOMRAT IT
            </a>
          </li>
        </ul>
      </nav> -->

    </footer>
    <!-- /bottom footer -->
  </div>
</body>

</html>
