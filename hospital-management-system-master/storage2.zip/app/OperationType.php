<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OperationType extends Model
{
    //
}
